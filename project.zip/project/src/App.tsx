import React, { useState, useEffect } from 'react';
import { ThumbsUp, ThumbsDown, Sun, Moon, Instagram, Facebook, Twitter, Linkedin, Send, Trash2, BarChart3, History, MessageSquare } from 'lucide-react';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { Toaster, toast } from 'react-hot-toast';
import { ClipLoader } from 'react-spinners';

// Initialize the Gemini API
const genAI = new GoogleGenerativeAI('AIzaSyCJhtg0vO-9lRgq1Xu8ThZ6Tm9sP2Bui34');

function App() {
  const [darkMode, setDarkMode] = useState(() => {
    const savedMode = localStorage.getItem('darkMode');
    return savedMode ? JSON.parse(savedMode) : window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  
  const [text, setText] = useState('');
  const [platform, setPlatform] = useState('twitter');
  const [sentiment, setSentiment] = useState<null | { score: number; analysis: string; }>(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<Array<{ text: string; platform: string; sentiment: { score: number; analysis: string; } }>>([]);

  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const analyzeSentiment = async () => {
    if (!text.trim()) {
      toast.error('Please enter some text to analyze');
      return;
    }

    setLoading(true);
    setSentiment(null);

    try {
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
      
      const prompt = `
        Analyze the sentiment of the following ${platform} post. 
        Provide a detailed analysis of the emotional tone, identifying positive and negative elements.
        Rate the sentiment on a scale from -1 (extremely negative) to 1 (extremely positive).
        Format your response as JSON with two fields:
        1. "score": the numerical score between -1 and 1
        2. "analysis": a 2-3 sentence explanation of the sentiment
        
        Text to analyze: "${text}"
      `;
      
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const responseText = response.text();
      
      // Extract JSON from the response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        const parsedResult = JSON.parse(jsonMatch[0]);
        setSentiment(parsedResult);
        
        // Add to history
        const newEntry = { 
          text, 
          platform, 
          sentiment: parsedResult 
        };
        
        setHistory(prev => [newEntry, ...prev]);
      } else {
        throw new Error("Failed to parse response");
      }
    } catch (error) {
      console.error('Error analyzing sentiment:', error);
      toast.error('Failed to analyze sentiment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const clearInput = () => {
    setText('');
    setSentiment(null);
  };

  const getSentimentColor = (score: number) => {
    if (score > 0.3) return 'text-emerald-500';
    if (score < -0.3) return 'text-rose-500';
    return 'text-amber-500';
  };

  const getSentimentBgColor = (score: number) => {
    if (score > 0.3) return darkMode ? 'bg-emerald-900/30' : 'bg-emerald-100';
    if (score < -0.3) return darkMode ? 'bg-rose-900/30' : 'bg-rose-100';
    return darkMode ? 'bg-amber-900/30' : 'bg-amber-100';
  };

  const getSentimentIcon = (score: number) => {
    if (score > 0.3) return <ThumbsUp className="w-6 h-6 text-emerald-500" />;
    if (score < -0.3) return <ThumbsDown className="w-6 h-6 text-rose-500" />;
    return (
      <div className="flex">
        <ThumbsUp className="w-5 h-5 text-amber-500 mr-1" />
        <ThumbsDown className="w-5 h-5 text-amber-500" />
      </div>
    );
  };

  const getSentimentLabel = (score: number) => {
    if (score > 0.7) return 'Very Positive';
    if (score > 0.3) return 'Positive';
    if (score > -0.3) return 'Neutral';
    if (score > -0.7) return 'Negative';
    return 'Very Negative';
  };

  const getPlatformIcon = (platformName: string) => {
    switch (platformName) {
      case 'instagram':
        return <Instagram className="w-5 h-5" />;
      case 'facebook':
        return <Facebook className="w-5 h-5" />;
      case 'twitter':
        return <Twitter className="w-5 h-5" />;
      case 'linkedin':
        return <Linkedin className="w-5 h-5" />;
      default:
        return <Twitter className="w-5 h-5" />;
    }
  };

  const getPlatformColor = (platformName: string) => {
    switch (platformName) {
      case 'instagram':
        return 'bg-gradient-to-r from-purple-500 to-pink-500';
      case 'facebook':
        return 'bg-blue-600';
      case 'twitter':
        return 'bg-sky-500';
      case 'linkedin':
        return 'bg-blue-700';
      default:
        return 'bg-sky-500';
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-200 ${darkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      <Toaster 
        position="top-center" 
        toastOptions={{
          style: {
            background: darkMode ? '#1f2937' : '#ffffff',
            color: darkMode ? '#ffffff' : '#000000',
            borderRadius: '8px',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
          }
        }}
      />
      
      {/* Header */}
      <header className={`p-4 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md sticky top-0 z-10`}>
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <BarChart3 className={`w-8 h-8 mr-2 ${darkMode ? 'text-indigo-400' : 'text-indigo-600'}`} />
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-purple-600">
              Sentify
            </h1>
          </div>
          <button 
            onClick={toggleDarkMode}
            className={`p-2 rounded-full transition-colors ${
              darkMode 
                ? 'bg-gray-700 hover:bg-gray-600 text-yellow-300' 
                : 'bg-gray-200 hover:bg-gray-300 text-indigo-600'
            }`}
            aria-label="Toggle dark mode"
          >
            {darkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
          </button>
        </div>
      </header>
      
      <main className="container mx-auto p-4 max-w-4xl">
        <div className={`mb-8 p-6 rounded-xl shadow-lg ${darkMode ? 'bg-gray-800/80 backdrop-blur-sm' : 'bg-white'} transition-all duration-300`}>
          <div className="flex items-center mb-4">
            <MessageSquare className={`w-5 h-5 mr-2 ${darkMode ? 'text-indigo-400' : 'text-indigo-600'}`} />
            <h2 className="text-xl font-semibold">Analyze New Content</h2>
          </div>
          
          {/* Platform Selection */}
          <div className="mb-6">
            <label className="block mb-2 font-medium text-sm">Select Platform:</label>
            <div className="flex flex-wrap gap-2">
              {['twitter', 'instagram', 'facebook', 'linkedin'].map((p) => (
                <button
                  key={p}
                  onClick={() => setPlatform(p)}
                  className={`flex items-center px-4 py-2 rounded-full transition-all duration-200 ${
                    platform === p 
                      ? `${getPlatformColor(p)} text-white shadow-md` 
                      : (darkMode ? 'bg-gray-700 hover:bg-gray-600 text-gray-200' : 'bg-gray-200 hover:bg-gray-300 text-gray-700')
                  }`}
                >
                  {getPlatformIcon(p)}
                  <span className="ml-2 capitalize">{p}</span>
                </button>
              ))}
            </div>
          </div>
          
          {/* Text Input */}
          <div className="mb-6">
            <label htmlFor="content" className="block mb-2 font-medium text-sm">Enter Content:</label>
            <div className="relative">
              <textarea
                id="content"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={`Type your ${platform} post here...`}
                className={`w-full p-4 rounded-lg border transition-colors duration-200 ${
                  darkMode 
                    ? 'bg-gray-700/70 border-gray-600 focus:border-indigo-500 text-white' 
                    : 'bg-white border-gray-300 focus:border-indigo-500 text-gray-900'
                } focus:ring-2 focus:ring-indigo-500 focus:outline-none`}
                rows={4}
              />
              {text && (
                <button 
                  onClick={clearInput}
                  className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                  aria-label="Clear input"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
            </div>
            <div className="flex justify-between mt-3">
              <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                {text.length} characters
              </span>
              <button
                onClick={analyzeSentiment}
                disabled={loading || !text.trim()}
                className={`flex items-center px-5 py-2 rounded-lg transition-all duration-200 ${
                  loading || !text.trim()
                    ? 'bg-gray-400 cursor-not-allowed opacity-70'
                    : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-md hover:shadow-lg'
                } text-white font-medium`}
              >
                {loading ? (
                  <ClipLoader size={20} color="#ffffff" />
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Analyze
                  </>
                )}
              </button>
            </div>
          </div>
          
          {/* Results */}
          {sentiment && (
            <div className={`mt-6 p-5 rounded-lg transition-all duration-300 ${getSentimentBgColor(sentiment.score)}`}>
              <div className="flex items-center mb-3">
                <h3 className="text-lg font-semibold">Sentiment Analysis</h3>
                <div className="ml-auto">
                  {getSentimentIcon(sentiment.score)}
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-4">
                <div className="flex-1">
                  <div className="mb-2">
                    <span className="font-medium text-sm">Score: </span>
                    <span className={`${getSentimentColor(sentiment.score)} font-bold`}>
                      {sentiment.score.toFixed(2)}
                    </span>
                  </div>
                  <div className="mb-1">
                    <span className="font-medium text-sm">Sentiment: </span>
                    <span className={`${getSentimentColor(sentiment.score)} font-bold`}>
                      {getSentimentLabel(sentiment.score)}
                    </span>
                  </div>
                </div>
                
                <div className="flex-1">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${
                        sentiment.score > 0.3 ? 'bg-emerald-500' : 
                        sentiment.score < -0.3 ? 'bg-rose-500' : 'bg-amber-500'
                      }`}
                      style={{ width: `${((sentiment.score + 1) / 2) * 100}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs mt-1">
                    <span className="text-rose-500">Negative</span>
                    <span className="text-amber-500">Neutral</span>
                    <span className="text-emerald-500">Positive</span>
                  </div>
                </div>
              </div>
              
              <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-700/50' : 'bg-white/80'}`}>
                <p className={darkMode ? 'text-gray-200' : 'text-gray-700'}>
                  {sentiment.analysis}
                </p>
              </div>
            </div>
          )}
        </div>
        
        {/* History */}
        {history.length > 0 && (
          <div className={`p-6 rounded-xl shadow-lg ${darkMode ? 'bg-gray-800/80 backdrop-blur-sm' : 'bg-white'} transition-all duration-300`}>
            <div className="flex items-center mb-4">
              <History className={`w-5 h-5 mr-2 ${darkMode ? 'text-indigo-400' : 'text-indigo-600'}`} />
              <h2 className="text-xl font-semibold">Analysis History</h2>
            </div>
            
            <div className="space-y-4">
              {history.map((item, index) => (
                <div 
                  key={index} 
                  className={`p-4 rounded-lg transition-all duration-200 ${getSentimentBgColor(item.sentiment.score)}`}
                >
                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${getPlatformColor(item.platform)}`}>
                        {getPlatformIcon(item.platform)}
                      </span>
                      <span className="capitalize font-medium">{item.platform}</span>
                    </div>
                    <div className="ml-auto flex items-center">
                      <span className={`text-sm font-medium mr-2 ${getSentimentColor(item.sentiment.score)}`}>
                        {item.sentiment.score.toFixed(2)}
                      </span>
                      {getSentimentIcon(item.sentiment.score)}
                    </div>
                  </div>
                  <p className={`mb-2 ${darkMode ? 'text-gray-200' : 'text-gray-700'} line-clamp-2`}>
                    {item.text}
                  </p>
                  <div className="text-sm">
                    <span className="font-medium">Sentiment: </span>
                    <span className={getSentimentColor(item.sentiment.score)}>
                      {getSentimentLabel(item.sentiment.score)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
      
      <footer className={`mt-8 py-6 ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
        <div className="container mx-auto text-center">
          <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
            <span className="font-medium bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-purple-600">Sentify</span> • Powered by Gemini AI • {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;